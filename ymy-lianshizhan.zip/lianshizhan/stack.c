#ifndef STACK_C_INCLUDED
#define STACK_C_INCLUDED

typedef struct SNode
{
int data;
struct SNode *next;
}SNode,*LinkStack;
// ������ʽջ�Ľṹ��
LinkStack top;

LinkStack PushStack(LinkStack top,int x);
LinkStack PopStack(LinkStack top);
int GetStackTop(LinkStack top);
void Print();
void lengh();

#endif // STACK_C_INCLUDED
