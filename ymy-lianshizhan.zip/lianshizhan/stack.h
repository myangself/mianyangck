#include"stack.c"

LinkStack PushStack(LinkStack top,int x) //��ջ
{
LinkStack s;
s=(LinkStack)malloc(sizeof(SNode));
s->data=x;
s->next=top;
top=s;
return top;
}


LinkStack PopStack(LinkStack top) //��ջ
{
LinkStack p;
if(top!=NULL)
{
p=top;
top=top->next;
free(p);
printf("��ջ�����\n");
return top;
}
else printf("ջ�ǿյģ��޷���ջ��\n"); return 0;
}

int GetStackTop(LinkStack top) //ȡջ��Ԫ��
{
return top->data;
}
bool IsEmpty()//boolȡֵfalse��true
{
return top==NULL ? true:false;
}

void Print() //�ж�ջ�Ƿ�Ϊ��
{
SNode *p;
p=top;
if(IsEmpty())
{
printf("The stack is empty!\n");
return;
}
while(p)
{
printf("%d ", p->data);
p=p->next;
}
printf("ջ��Ϊ��");
printf("\n");
}

void lengh()
{
 SNode *p;
 p=top;
 int i=0;
 while(p){i++; p=p->next;}
 printf("ջ�ĳ���Ϊ%d",i);

}
